﻿using testLib;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;
using System.Management;

NotifyIcon notifyIcon = new();
notifyIcon.Icon = Icon.ExtractAssociatedIcon("C:\\Program Files (x86)\\Razer\\Synapse3\\WPFUI\\Framework\\Razer Synapse 3 Host\\Razer Synapse 3.exe");
notifyIcon.Text = "123";
notifyIcon.BalloonTipIcon = ToolTipIcon.None;
notifyIcon.BalloonTipTitle = "Notification about changes in screen refresh rate";
notifyIcon.BalloonTipClicked += (sender, e) =>
{
    var thisIcon = (NotifyIcon)sender;
    thisIcon.Visible = false;
    thisIcon.Dispose();
};
notifyIcon.BalloonTipClosed += (sender, e) =>
{
    var thisIcon = (NotifyIcon)sender;
    thisIcon.Visible = false;
    thisIcon.Dispose();
};
UInt16 b = Battery.GetBatteryChargingStatus();
UInt32 currentRefreshRate = PrimaryScreen.GetScreenRefreshRate();
if (b == 2)
{
    if (currentRefreshRate != 165)
    {
        notifyIcon.Visible = true;
        PrimaryScreen.ChangeRefreshRate(165);
        notifyIcon.BalloonTipText = "Текущая частота обновления экрана: 165 гц";
        notifyIcon.ShowBalloonTip(10);
    }
}
else
{
    if (currentRefreshRate != 60)
    {
        notifyIcon.Visible = true;
        PrimaryScreen.ChangeRefreshRate(60);
        notifyIcon.BalloonTipText = "Текущая частота обновления экрана: 60 гц";
        notifyIcon.ShowBalloonTip(10);
    }
}