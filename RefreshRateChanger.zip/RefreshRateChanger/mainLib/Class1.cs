﻿using System;
using System.Management;
using System.Runtime.InteropServices;
using static System.Management.ManagementObjectCollection;

namespace mainLib
{
    public class Battery
    {
        public static ushort GetBatteryChargingStatus()
        {
            ManagementClass val = new ManagementClass("Win32_Battery");
            ManagementObjectCollection instances = val.GetInstances();
            if (instances.Count == 1)
            {
                System.Management.ManagementObjectCollection.ManagementObjectEnumerator enumerator = instances.GetEnumerator();
                try
                {
                    if (enumerator.MoveNext())
                    {
                        ManagementObject val2 = (ManagementObject)enumerator.Current;
                        return (ushort)((ManagementBaseObject)val2).Properties["BatteryStatus"].Value;
                    }
                }
                finally
                {
                    ((IDisposable)enumerator)?.Dispose();
                }
            }
            return 0;
        }
    }

    public struct DEVMODE1
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string dmDeviceName;

        public short dmSpecVersion;

        public short dmDriverVersion;

        public short dmSize;

        public short dmDriverExtra;

        public int dmFields;

        public short dmOrientation;

        public short dmPaperSize;

        public short dmPaperLength;

        public short dmPaperWidth;

        public short dmScale;

        public short dmCopies;

        public short dmDefaultSource;

        public short dmPrintQuality;

        public short dmColor;

        public short dmDuplex;

        public short dmYResolution;

        public short dmTTOption;

        public short dmCollate;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string dmFormName;

        public short dmLogPixels;

        public short dmBitsPerPel;

        public int dmPelsWidth;

        public int dmPelsHeight;

        public int dmDisplayFlags;

        public int dmDisplayFrequency;

        public int dmICMMethod;

        public int dmICMIntent;

        public int dmMediaType;

        public int dmDitherType;

        public int dmReserved1;

        public int dmReserved2;

        public int dmPanningWidth;

        public int dmPanningHeight;
    }

    public class PrimaryScreen
    {
        public static uint GetScreenRefreshRate()
        {
            uint result = 0u;
            ManagementClass val = new ManagementClass("Win32_VideoController");
            ManagementObjectCollection instances = val.GetInstances();
            ManagementObjectEnumerator enumerator = instances.GetEnumerator();
            try
            {
                while (enumerator.MoveNext())
                {
                    ManagementObject val2 = (ManagementObject)enumerator.Current;
                    if (((ManagementBaseObject)val2).Properties["CurrentRefreshRate"].Value != null)
                    {
                        result = (uint)((ManagementBaseObject)val2).Properties["CurrentRefreshRate"].Value;
                    }
                }
            }
            finally
            {
                ((IDisposable)enumerator)?.Dispose();
            }
            return result;
        }

        public static string ChangeRefreshRate(int frequency)
        {
            DEVMODE1 devMode = GetDevMode1();
            if (User_32.EnumDisplaySettings(null, -1, ref devMode) != 0)
            {
                devMode.dmDisplayFrequency = frequency;
                int num = User_32.ChangeDisplaySettings(ref devMode, 2);
                if (num == -1)
                {
                    return "Unable to process your request. Sorry for this inconvenience.";
                }
                return User_32.ChangeDisplaySettings(ref devMode, 1) switch
                {
                    0 => "Success",
                    1 => "You need to reboot for the change to happen.\n If you feel any problems after rebooting your machine\nThen try to change resolution in Safe Mode.",
                    _ => "Failed to change the resolution",
                };
            }
            return "Failed to change the resolution.";
        }

        private static DEVMODE1 GetDevMode1()
        {
            DEVMODE1 dEVMODE = default(DEVMODE1);
            dEVMODE.dmDeviceName = new string(new char[32]);
            dEVMODE.dmFormName = new string(new char[32]);
            dEVMODE.dmSize = (short)Marshal.SizeOf(dEVMODE);
            return dEVMODE;
        }
    }

    internal class User_32
    {
        public const int ENUM_CURRENT_SETTINGS = -1;

        public const int CDS_UPDATEREGISTRY = 1;

        public const int CDS_TEST = 2;

        public const int DISP_CHANGE_SUCCESSFUL = 0;

        public const int DISP_CHANGE_RESTART = 1;

        public const int DISP_CHANGE_FAILED = -1;

        [DllImport("user32.dll")]
        public static extern int EnumDisplaySettings(string? deviceName, int modeNum, ref DEVMODE1 devMode);

        [DllImport("user32.dll")]
        public static extern int ChangeDisplaySettings(ref DEVMODE1 devMode, int flags);
    }


}